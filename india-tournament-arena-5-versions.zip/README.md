# India Tournament Arena - 5 versions (alag-alag typing)

Sab versions ka design bilkul video jaisa hai, sirf likha hua text alag hai.

| Folder | Typing |
|---|---|
| 1-hinglish-original | Aapka asli page (video wala), bina badle |
| 2-hinglish-alternate | Hinglish, alag shabd aur heading |
| 3-hindi-devanagari | Poora Hindi (Devanagari) |
| 4-english | English |
| 5-short-simple | Chhota aur simple Hinglish |

## Upload kaise karein (har version ke liye alag GitHub repository)
1. Naya repository banayein.
2. Chune hue folder ke andar ki saari files upload karein (index.html, robots.txt, sitemap.xml, .nojekyll).
3. Upar wali `freefire-tournament.apk` file bhi usi repository mein upload karein (naam same rakhein).
4. Settings -> Pages -> Branch: main, / (root) -> Save.

## Zaroori badlav (folder 2, 3, 4, 5 mein)
`index.html`, `robots.txt` aur `sitemap.xml` mein `https://USERNAME.github.io/REPO/` likha hai.
Use apne asli link se badal dein (find & replace), jaise `https://aapkaname.github.io/repoName/`.
Folder 1 mein aapka purana link pehle se laga hua hai.
